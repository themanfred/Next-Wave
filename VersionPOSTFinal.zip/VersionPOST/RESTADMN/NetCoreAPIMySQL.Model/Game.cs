﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCoreAPIMySQL.Model
{
    public class Game
    {
        public int Applicantid2 { get; set; }
        public int Game_score { get; set; }
        public int Vacancy_option { get; set; }
    }
}
