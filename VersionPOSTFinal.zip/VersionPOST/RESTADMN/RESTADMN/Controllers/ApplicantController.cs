﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NetCoreAPIMySQL.Data.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RESTADMN.Controllers
{
    [Route("api/Aplicant")]
    [ApiController]
    public class ApplicantController : ControllerBase
    {
        private readonly IApplicantRepository _applicantRepository;

        public ApplicantController(IApplicantRepository applicantRepository)
        {
            _applicantRepository = applicantRepository;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllApplicants()
        {

            return Ok(await _applicantRepository.GetAllApplicants());
        }

        [HttpGet ("id/{id}")]
        public async Task<IActionResult> GetApplicantsDetails(int id)
        {

            return Ok(await _applicantRepository.GetApplicantsDetails(id));
        }

        
        [HttpGet("correo/{megam1}")]
        public async Task<IActionResult> GetApplicantByEmail(string megam1)
        {

            return Ok(await _applicantRepository.GetApplicantByEmail(megam1));
        }

    }
}

