﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NetCoreAPIMySQL.Data.Repositories;
using NetCoreAPIMySQL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RESTADMN.Controllers
{
    [Route("api/game")]
    [ApiController]
    public class GameController : ControllerBase
    {
        private readonly IGameRepository _gameRepository;

        public GameController(IGameRepository gameRepository)
        {
            _gameRepository = gameRepository;
        }

        [HttpPost("/id={appid}&score={appscore}&vacancy={vacancyid}")]
        public async Task<IActionResult> CreateGameTry(/*[FromBody] Game gamer*/int appid, int appscore, int vacancyid)
        {
            /*if (gamer == null)
                return BadRequest();

            if (!ModelState.IsValid)
                return BadRequest(ModelState);*/

            var created = await _gameRepository.InsertGameTry(/*gamer*/appid, appscore, vacancyid);

            return Created("Created", created);
        }

    }
}
